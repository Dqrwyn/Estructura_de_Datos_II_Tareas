# nodo.py

class Nodo:
    def __init__(self, valor):
        self.valor = valor  # Almacena el valor del nodo
        self.siguiente = None  # Referencia al siguiente nodo (inicialmente None)a